#include <iostream>
#include <string>
using namespace std;

// Implement your code



int main() {
    Person p1{"Park"};
    p1.print();

    Student s1 {"Kim", "PNU"};
    s1.print();

    return 0;
}