# Empty compiler generated dependencies file for LAB3_71.
# This may be replaced when dependencies are built.
