//pccp에서 다른 부분은 원래 백준,프로그래머스 공부가 부족했어서 알고리즘을 잘 몰랐다고는 하지만,
//string 문자열 파싱 부분은 확실하게 알고 있었어야 했다;;;
//그러므로 다시한번 해보고 확실히 알아두자(그리고 ps에서는 \n으로 구분되는 문자열은 무조건 cin으로 받아야 한다 스페이스바는 stringstream)

#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include <cmath> //distance 함수
#include <numeric> //accumulate 함수
using namespace std;

//주어지는 배열 3개(vector>
//참가자 ["KIM", "PARK", "LEE", "YOO", "BAE"]
//프로젝트 ["KIM PARK", "PARK LEE YOO", "BAE KIM", "YOO BAE LEE PARK", "YOO LEE PARK", "KIM YOO"]
// 연차 [90, 160, 160, 1000, 100]

// 프로젝트 한 원소에 들어가있는 " "로 구별된 사람들이 한 프로젝트에 들어가는 사람들.
// 참가자 배열의 인덱스0이 이전 팀장 경험 있는 사람
// 최종 팀장 배열은 프로젝트 배열의 길이와 같음

//최종 목표는 각 프로젝트별 

/*
팀장이 되는 우선순위
1순위. 이전 팀장 경험이 있는 사람
2순위. 이전 팀장 경험이 없으면 연차가 높은 사람
3순위. 연차가 같은 경우에는 이름의 사전순
*/



//내가 생각한 첫번째 전략 => 프로젝트 배열을 파싱해서 2차원 배열로 만들어서 프로젝트 별로 참가자를 구별할 수 있게 하고, 프로젝트의 팀장을 정하자
//근데 왜 이중 범위기반 for문이 안되는 걸까? <-- 일단 이거 어떻게든 해결해보셈


vector<string> solution(vector<string> member, vector<int> period, vector<string> project);

int main(){

    vector<string> member = {"KIM", "PARK", "LEE", "YOO", "BAE"};
    //팁1) 이렇게 바로 vector에 원소를 넣고 싶으면 {} 중괄호(스코프) 사용해야함
    vector<int> period = {90, 160, 160, 1000, 100};
    vector<string> project = {"KIM PARK", "PARK LEE YOO", "BAE KIM", "YOO BAE LEE PARK", "YOO LEE PARK", "KIM YOO"};

    vector<string> temp = solution(member,period,project);

    for(const auto& lt : temp){
        cout << lt << " ";
    }
}

vector<string> solution(vector<string> member, vector<int> period, vector<string> project){
    vector<string> vec = {"h","e"};

    return vec;
}
